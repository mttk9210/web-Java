
package Java;

import java.sql.*; //SQLに関連したクラスライブラリをインポート

public class CommentDB {

    /* 1. フィールドの定義 */
    protected int[] film_id = new int[30];
    protected int[] director_id = new int[30];
    protected int[] company_id = new int[30];
    protected String[] film_name = new String[30];
    protected String[] company_name = new String[30];
    protected String[] director_name = new String[30];
    protected String[] comment = new String[30];
    protected Date[] date = new Date[30];
    protected String[] twitter_widgets_url = new String[30];
    protected String[] twitter_widgets_id = new String[30];
    protected int num;//データ取得件数
    protected int num1;//データ取得件数
    protected int num2;//データ取得件数

    /* 2. メソッド */
 /* 2.1 データベースからのデータ取得メソッド */
    public void dataload1() throws Exception { //エラー処理が必要にする
/* 2.1.1 データベースに接続 */
        num = 0; //取得件数の初期化
        Class.forName("com.mysql.jdbc.Driver").newInstance(); //com.mysql.jdbc.Driverはドライバのクラス名
        String url = "jdbc:mysql://localhost/movie?characterEncoding=UTF-8"; //データベース名：文字エンコードはUTF-8
        Connection conn = DriverManager.getConnection(url, "root", "sugawara0902"); //上記URL設定でユーザ名とパスワードを使って接続

        /* 2.1.2 SELECT文の実行 */ String sql = "select * "
                + "from film "; //SQL文の設定 ?などパラメータが必要がない場合は通常のStatementを利用
        PreparedStatement stmt = conn.prepareStatement(sql); //JDBCのステートメント（SQL文）の作成
        stmt.setMaxRows(100); //最大の数を制限
        ResultSet rs = stmt.executeQuery(); //ステートメントを実行しリザルトセットに代入

        /* 2.1.3 結果の取り出しと表示 */
        while (rs.next()) { //リザルトセットを1行進める．ない場合は終了
            this.film_name[num] = rs.getString("film_name");
             this.film_id[num] = rs.getInt("film_id");
            num++;
        }

        /* 2.1.4 データベースからの切断 */
        rs.close(); //開いた順に閉じる
        stmt.close();
        conn.close();
    }

        public void dataload2() throws Exception { //エラー処理が必要にする
/* 2.1.1 データベースに接続 */
        num = 0; //取得件数の初期化
        Class.forName("com.mysql.jdbc.Driver").newInstance(); //com.mysql.jdbc.Driverはドライバのクラス名
        String url = "jdbc:mysql://localhost/movie?characterEncoding=UTF-8"; //データベース名：文字エンコードはUTF-8
        Connection conn = DriverManager.getConnection(url, "root", "sugawara0902"); //上記URL設定でユーザ名とパスワードを使って接続

        /* 2.1.2 SELECT文の実行 */ String sql = "select * "
                + " from comment inner join film on comment.film_id = film.film_id "; //SQL文の設定 ?などパラメータが必要がない場合は通常のStatementを利用
        PreparedStatement stmt = conn.prepareStatement(sql); //JDBCのステートメント（SQL文）の作成
        stmt.setMaxRows(100); //最大の数を制限
        ResultSet rs = stmt.executeQuery(); //ステートメントを実行しリザルトセットに代入

        /* 2.1.3 結果の取り出しと表示 */
        while (rs.next()) { //リザルトセットを1行進める．ない場合は終了
            this.film_name[num] = rs.getString("film_name");
             this.film_id[num] = rs.getInt("film_id");
             this.date[num] = rs.getDate("date");
             this.comment[num] = rs.getString("comment");
            num++;
        }

        /* 2.1.4 データベースからの切断 */
        rs.close(); //開いた順に閉じる
        stmt.close();
        conn.close();
    }
    
    /* 2.2 データベースへのインサートメソッド */
    public int insert(String comment, int film) {
        int count = 0; //登録件数のカウント
        try {

            /* 2.2.1 データベースに接続 */
            Class.forName("com.mysql.jdbc.Driver").newInstance(); // SELECTの時と同じ
            String url = "jdbc:mysql://localhost/movie?characterEncoding=UTF-8";
            Connection conn = DriverManager.getConnection(url, "root", "sugawara0902");

            /* 2.2.2 INSERT文の実行 */
            String sql = "INSERT INTO comment (date,comment,film_id)"
                    + " VALUES (now(),?,?)"; //SQL文の設定 INSERTはパラメータが必要なことが多い

            PreparedStatement stmt = conn.prepareStatement(sql); //JDBCのステートメント（SQL文）の作成
            stmt.setString(1, comment);
            stmt.setInt(2, film);

            /* 2.2.3 実行（UpdateやDeleteも同じメソッドを使う） */
            count = stmt.executeUpdate();

            /* 2.2.4 データベースからの切断 */
            stmt.close();
            conn.close();
            return count;
        } catch (Exception e) {
            return 0;
        }
    }

    /* 3. アクセッサ */
 /* 3.1 Getアクセッサ */
    public int getFilmId(int i) {
        if (i >= 0 && num > i) {
            return film_id[i];
        } else {
            return 0;
        }
    }



    public String getFilmName(int i) {
        if (i >= 0 && num > i) {
            return film_name[i];
        } else {
            return "";
        }
    }



    public String getCommment(int i) {
        if (i >= 0 && num > i) {
            return comment[i];
        } else {
            return "";
        }
    }

    public Date getDate(int i) {
        if (i >= 0 && num > i) {
            return date[i];
        } else {
            return null;
        }
    }

    public int getNum() {
        return num; // データ件数
    }

    public int getNum1() {
        return num1; // データ件数
    }

    public int getNum2() {
        return num2; // データ件数
    }

}
